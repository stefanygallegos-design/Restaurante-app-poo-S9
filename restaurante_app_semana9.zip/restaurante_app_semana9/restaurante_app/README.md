# restaurante_app - Semana 9

## Nombre del estudiante
[Escribir aquí el nombre completo del estudiante]

## Descripción

Este proyecto corresponde a la Semana 9 de Programación Orientada a Objetos.
Es una evolución del sistema `restaurante_app` y administra productos y usuarios
mediante una arquitectura modular.

El proyecto conserva la separación entre:

- `modelos/`: representa las entidades del sistema.
- `servicios/`: administra las colecciones y operaciones.
- `main.py`: coordina el menú y la interacción por consola.

## Estructura del proyecto

```text
restaurante_app/
├── modelos/
│   ├── __init__.py
│   ├── producto.py
│   └── usuario.py
├── servicios/
│   ├── __init__.py
│   └── restaurante.py
├── main.py
└── README.md
```

## Responsabilidad de los archivos

### modelos/producto.py
Contiene la clase `Producto`, con:

- código
- nombre
- categoría
- precio

### modelos/usuario.py
Contiene la clase `Usuario`, con:

- identificación
- nombre
- correo

### servicios/restaurante.py
Contiene la clase `Restaurante`, encargada de administrar:

- lista de productos
- lista de usuarios
- registro
- búsqueda
- actualización
- eliminación
- listado
- categorías únicas

### main.py
Es el punto de entrada del programa. Muestra el menú, solicita datos mediante
`input()`, crea objetos y utiliza los métodos de `Restaurante`.

## Estructuras de datos utilizadas

### Lista (`list`)
Se utilizan dos listas dentro de `Restaurante`:

```python
self._productos: list[Producto] = []
self._usuarios: list[Usuario] = []
```

La lista es apropiada porque productos y usuarios son colecciones dinámicas:
pueden registrarse, buscarse, actualizarse y eliminarse durante la ejecución.

### Tupla (`tuple`)
El menú se representa mediante una tupla:

```python
OPCIONES_MENU = (
    ("1", "Registrar producto"),
    ("2", "Buscar producto"),
    ("3", "Actualizar producto"),
    ("4", "Eliminar producto"),
    ("5", "Listar productos"),
    ("6", "Registrar usuario"),
    ("7", "Listar usuarios"),
    ("8", "Mostrar categorías"),
    ("9", "Salir"),
)
```

Se utiliza porque las opciones del menú forman una configuración estable del
programa y no necesitan modificarse durante la ejecución.

### Diccionario (`dict`)
Las opciones del menú se relacionan con las funciones mediante un diccionario:

```python
opciones = {
    "1": registrar_producto,
    "2": buscar_producto,
    "3": actualizar_producto,
    "4": eliminar_producto,
    "5": listar_productos,
    "6": registrar_usuario,
    "7": listar_usuarios,
    "8": mostrar_categorias,
    "9": salir,
}
```

La clave representa la opción seleccionada y el valor representa la función que
debe ejecutarse. Esto evita una cadena extensa de `if/elif`.

### Conjunto (`set`)
Las categorías se obtienen mediante un conjunto:

```python
categorias: set[str] = set()

for producto in self._productos:
    categorias.add(producto.categoria)
```

El conjunto es adecuado porque una misma categoría puede aparecer en varios
productos y se necesita mostrarla una sola vez.

## Operaciones CRUD

El sistema implementa las operaciones principales sobre productos:

- **Create:** registrar producto.
- **Read:** buscar y listar productos.
- **Update:** actualizar producto.
- **Delete:** eliminar producto.

También permite registrar y listar usuarios.

## Validaciones y excepciones

El programa valida datos de entrada y utiliza `try/except` para evitar que una
entrada numérica incorrecta detenga la ejecución.

Las clases también validan:

- campos obligatorios
- precio no negativo
- identificaciones y códigos no duplicados mediante el servicio

## Ejecución

Desde la carpeta `restaurante_app`, ejecutar:

```bash
python main.py
```

El programa mostrará un menú interactivo por consola.

## Reflexión

La selección de una estructura de datos debe responder a una necesidad concreta.
En este proyecto, las listas permiten administrar colecciones dinámicas, la tupla
mantiene estable la configuración del menú, el diccionario relaciona cada opción
con una función y el conjunto permite obtener categorías sin duplicados.

Estas estructuras complementan a las clases: las clases representan las entidades
del sistema y las colecciones permiten administrar grupos de objetos y relaciones.
